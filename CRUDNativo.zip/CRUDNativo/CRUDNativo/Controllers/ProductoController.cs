﻿using CRUDNativo.Data;
using CRUDNativo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDNativo.Controllers
{
    public class ProductoController : Controller
    {
        public readonly ApplicationDbContext _context;
        public ProductoController(ApplicationDbContext context)
        {
            _context = context;
        }
        // Metodo Get
        public ActionResult Index()
        {
            IEnumerable<Producto> listaProductos = _context.Productos;
            return View(listaProductos);
        }
        // Metodo Get Crear
        public ActionResult crear()
        {
            return View();
        }
        // Metodo Post Crear
        [HttpPost]
        public IActionResult crear(Producto producto)
        {
            if (ModelState.IsValid)
            {
                _context.Productos.Add(producto);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(producto);
        }
        // Metodo Get Edit
        public IActionResult Editar(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var producto = _context.Productos.Find(id);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }
        // metodo POST editar
        [HttpPost]
        public IActionResult Editar(Producto producto)
        {
            if (ModelState.IsValid)
            {
                _context.Productos.Update(producto);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        // Metodo Get Delete
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var producto = _context.Productos.Find(id);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }
        // metodo POST delete
        [HttpPost]
        public IActionResult DeleteProducto(int? id)
        {
            var producto = _context.Productos.Find(id);
            if (producto == null)
            {
                return NotFound();
            }
            _context.Productos.Remove(producto);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
